import { IBotPlugin, IBot } from '../resources';

export default class SoundcloudPlugin implements IBotPlugin {

    preInitialize(bot: IBot): void {
        // TODO WIP
    }

    postInitialize(bot: IBot): void {
        
    }

}
